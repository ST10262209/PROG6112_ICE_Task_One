/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetaskoneanimal;

/**
 *
 * @author cadec
 */
public class Reptile extends Animal {
    private double bloodTemp;
    
    public Reptile(int IDtag, String species){
        super(IDtag, species);
    }
    
    public double getBloodTemp(){
        return bloodTemp;
    }
    
    @Override
    public void inputValues(){
            super.inputValues();
            System.out.println("Please enter the temperature of the animals blood");
            bloodTemp = kb.nextDouble();  
            kb.nextLine();
    }
    
    @Override
    public void outputValues(){
        super.outputValues();
        System.out.println("The temperature of the animals blood is " + bloodTemp);
    }
}
