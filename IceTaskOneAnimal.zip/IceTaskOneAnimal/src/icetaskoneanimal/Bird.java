/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetaskoneanimal;

/**
 *
 * @author cadec
 */
public class Bird extends Animal {
    private String colour;
    int option;
    
    public int [] featherColourI = {1, 2, 3};
    public String [] featherColourS = {"grey" , "white" , "black"};

    public Bird(int IDtag, String species) {
        super(IDtag, species);
    }
    
    @Override
    public void inputValues(){
        super.inputValues();
         while (true) {
            System.out.println("From the following options:");
            for (int i = 0; i < featherColourS.length; i++) {
                System.out.println((i + 1) + " - " + featherColourS[i]);
            }
            
            System.out.println("Please enter the option number of the colour of the bird:");
            option = kb.nextInt();
            
            if (option >= 1 && option <= featherColourS.length) {
                colour = featherColourS[option - 1];
                break; // Valid input, exit the loop
            } else {
                System.out.println("Invalid option. Please select a valid option.");
            }
        }
    }
    
    @Override
    public void outputValues(){
         super.outputValues();
         System.out.println("feather colour: " + colour);
    }
    
    
    
    
}
